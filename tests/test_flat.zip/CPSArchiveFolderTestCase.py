from Testing import ZopeTestCase
from Products.CPSDefault.tests import CPSTestCase

CPSTestCase.setupPortal()

CPSArchiveFolderTestCase = CPSTestCase.CPSTestCase

