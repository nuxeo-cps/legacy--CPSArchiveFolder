# TODO: 
# - don't depend on getDocumentSchemas / getDocumentTypes but is there
#   an API for that ?

import os, sys
if __name__ == '__main__':
    execfile(os.path.join(sys.path[0], 'framework.py'))

from pprint import pprint
import unittest
from Testing import ZopeTestCase
import CPSArchiveFolderTestCase


class Test(CPSArchiveFolderTestCase.CPSArchiveFolderTestCase):
    def afterSetUp(self):
        self.login('root')
        self.ws = self.portal.workspaces

    def beforeTearDown(self):
        self.logout()


def test_suite():
    suite = unittest.TestSuite()
    suite.addTest(unittest.makeSuite(Test))
    return suite

